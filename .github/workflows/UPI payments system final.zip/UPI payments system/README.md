# UPI Payments System - Flask Backend Setup

## Overview

This project contains a Flask backend for user signup and login with CORS support enabled.

## Setup Instructions

1. Install dependencies:

```bash
pip install flask flask-cors
```

2. Run the backend server:

```bash
python app.py
```

The server will run on port 5500 and expose the following endpoints:

- `POST /signup` - Create a new user account. Expects JSON with `email` and `password`.
- `POST /login` - Login with existing user credentials. Expects JSON with `email` and `password`.

## Frontend

Ensure your frontend (signup.html, login.html) sends requests to `http://localhost:5500/signup` and `http://localhost:5500/login`.

## Notes

- The user data is stored in-memory and will reset when the server restarts.
- CORS is enabled to allow cross-origin requests from the frontend.
