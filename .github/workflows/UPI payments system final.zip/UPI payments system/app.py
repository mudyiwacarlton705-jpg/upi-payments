#!/usr/bin/env python3
# payment_system_full.py
# Single-file Flask app: User/Admin signup & login, dashboards, add cards, payments

from flask import Flask, request, redirect, url_for, session, flash, render_template_string, send_file, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os, datetime, io, csv
from functools import wraps

app = Flask(__name__)
app.secret_key = os.environ.get("APP_SECRET_KEY", "supersecretkey_demo_only")

DB_NAME = "payment_system.db"

# Add CORS headers for cross-origin requests
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    return response

# ---------------- Database Setup ----------------
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Users table
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('user','admin'))
        )
    """)
    # Cards table
    c.execute("""
        CREATE TABLE IF NOT EXISTS cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            card_masked TEXT NOT NULL,
            last4 TEXT NOT NULL,
            card_brand TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    # Payments table
    c.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            card_last4 TEXT,
            amount REAL NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    # Bank details table
    c.execute("""
        CREATE TABLE IF NOT EXISTS bank_details (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            bank_name TEXT NOT NULL,
            account_number TEXT NOT NULL,
            ifsc_code TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)
    conn.commit()
    conn.close()

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

# ---------------- Utilities ----------------
def mask_card_number(number: str):
    num = "".join(number.split())
    last4 = num[-4:] if len(num) >= 4 else num
    masked = "**** **** **** " + last4
    brand = "Unknown"
    if num.startswith("4"):
        brand = "Visa"
    elif num.startswith(("51","52","53","54","55")):
        brand = "Mastercard"
    return masked, last4, brand

def current_time_iso():
    return datetime.datetime.utcnow().isoformat() + "Z"

def create_session_for_user(user_row):
    session['user_id'] = user_row['id']
    session['user_name'] = user_row['name']
    session['role'] = user_row['role']

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'role' not in session or session['role'] != 'admin':
            return jsonify({'message': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated_function

# ---------------- Base Template ----------------
base_template = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{{ title }}</title>
<style>
body { font-family: Arial, sans-serif; background:#f4f4f9; margin:0; text-align:center; }
.container { max-width:1000px; margin:30px auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.08); text-align:left; }
.header { display:flex; justify-content:space-between; align-items:center; }
nav a { margin-right:12px; color:#007bff; text-decoration:none; }
.form-row { margin:10px 0; }
input[type=text], input[type=email], input[type=password], input[type=number], select { width:100%; padding:10px; box-sizing:border-box; border:1px solid #ddd; border-radius:6px; }
button { padding:10px 16px; background:#007bff; color:#fff; border:none; border-radius:6px; cursor:pointer; }
table { width:100%; border-collapse:collapse; margin-top:10px; }
th, td { padding:8px; border-bottom:1px solid #eee; text-align:left; }
.flash { padding:10px; border-radius:6px; margin:10px 0; }
.flash.success { background:#d4edda; color:#155724; }
.flash.error { background:#f8d7da; color:#721c24; }
.flash.info { background:#d1ecf1; color:#0c5460; }
.card { display:inline-block; background:#fafafa; padding:12px; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,0.04); margin:6px; }
.small { font-size:0.9em; color:#666; }
select { height:42px; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <h2>{{ title }}</h2>
      <div class="small">Demo Payment System — do NOT use real card details in production.</div>
    </div>
    <div>
      {% if session.user_name %}
        <div style="text-align:right;">
          Logged in as <strong>{{ session.user_name }}</strong> (<em>{{ session.role }}</em>)<br>
          <nav>
            <a href="{{ url_for('home') }}">Home</a>
            {% if session.role == 'user' %}<a href='{{ url_for('dashboard') }}'>My Dashboard</a>{% endif %}
            {% if session.role == 'admin' %}<a href='{{ url_for('admin_dashboard') }}'>Admin Dashboard</a>{% endif %}
            <a href='{{ url_for('logout') }}'>Logout</a>
          </nav>
        </div>
      {% else %}
        <nav>
          <a href="{{ url_for('home') }}">Home</a>
          <a href="{{ url_for('signup') }}">User Sign Up</a>
          <a href="{{ url_for('login') }}">User Login</a>
          <a href="{{ url_for('admin_signup') }}">Admin Sign Up</a>
          <a href="{{ url_for('admin_login') }}">Admin Login</a>
        </nav>
      {% endif %}
    </div>
  </div>

  {% with messages = get_flashed_messages(with_categories=true) %}
    {% if messages %}
      {% for category, msg in messages %}
        <div class="flash {{ category }}">{{ msg }}</div>
      {% endfor %}
    {% endif %}
  {% endwith %}

  {{ content|safe }}
</div>
</body>
</html>"""

# ---------------- Routes ----------------
from flask import send_from_directory

@app.route('/')
def home():
    return send_from_directory('.', 'Index.html')

# ----------- User Signup/Login -----------
@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method=='POST':
        # Check if it's an API request (JSON) or form submission
        if request.is_json:
            # Handle JSON API request
            data = request.get_json()
            name = data.get('name', '').strip()
            email = data.get('email', '').strip().lower()
            password = data.get('password', '')

            if not (name and email and password):
                return jsonify({'message': 'Name, email, and password are required'}), 400

            db = get_db()
            c = db.cursor()
            try:
                c.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
                          (name, email, generate_password_hash(password), 'user'))
                db.commit()
                return jsonify({'message': 'User created successfully'}), 201
            except sqlite3.IntegrityError:
                return jsonify({'message': 'Email already exists'}), 409
            except sqlite3.OperationalError as e:
                return jsonify({'message': f'Database error: {e}'}), 500
            finally:
                db.close()
        else:
            # Handle form submission
            name = request.form.get('name','').strip()
            email = request.form.get('email','').strip().lower()
            password = request.form.get('password','')
            if not (name and email and password):
                flash('All fields required.', 'error'); return redirect(url_for('signup'))
            db=get_db(); c=db.cursor()
            try:
                c.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
                          (name,email,generate_password_hash(password),'user'))
                db.commit(); user_id=c.lastrowid
                create_session_for_user({'id':user_id,'name':name,'role':'user'})
                flash('Signup successful.', 'success'); return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError:
                flash('Email already exists. Try logging in.', 'error'); return redirect(url_for('signup'))
            except sqlite3.OperationalError as e:
                flash(f'Database error: {e}', 'error'); return redirect(url_for('signup'))
            finally:
                db.close()

    return send_from_directory('.', 'signup.html')

from flask import send_from_directory, render_template_string

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        # Check if it's an API request (JSON) or form submission
        if request.is_json:
            # Handle JSON API request
            data = request.get_json()
            email = data.get('email', '').strip().lower()
            password = data.get('password', '')

            if not (email and password):
                return jsonify({'message': 'Email and password are required'}), 400

            db = get_db()
            c = db.cursor()
            c.execute('SELECT * FROM users WHERE email=?', (email,))
            row = c.fetchone()
            db.close()

            if row and check_password_hash(row['password'], password):
                return jsonify({
                    'message': 'Login successful',
                    'role': row['role'],
                    'name': row['name']
                }), 200
            else:
                return jsonify({'message': 'Invalid credentials'}), 401
        else:
            # Handle form submission
            email=request.form.get('email','').strip().lower()
            password=request.form.get('password','')
            db=get_db(); c=db.cursor()
            c.execute('SELECT * FROM users WHERE email=? AND role=?',(email,'user'))
            row=c.fetchone()
            if row and check_password_hash(row['password'],password):
                create_session_for_user(row); flash('Login successful.','success'); return redirect(url_for('dashboard'))
            flash('Invalid credentials.','error'); return redirect(url_for('login'))

    return send_from_directory('.', 'login.html')

# ----------- Admin Signup/Login -----------
@app.route('/admin_signup', methods=['GET','POST'])
def admin_signup():
    if request.method=='POST':
        name=request.form.get('name','').strip()
        email=request.form.get('email','').strip().lower()
        password=request.form.get('password','')
        if not (name and email and password):
            flash('All fields required.','error'); return redirect(url_for('admin_signup'))
        db=get_db(); c=db.cursor()
        try:
            c.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
                      (name,email,generate_password_hash(password),'admin'))
            db.commit(); user_id=c.lastrowid
            create_session_for_user({'id':user_id,'name':name,'role':'admin'})
            flash('Admin signup successful.','success'); return redirect(url_for('admin_dashboard'))
        except sqlite3.IntegrityError:
            flash('Admin email already exists. Try login.','error'); return redirect(url_for('admin_signup'))

    return send_from_directory('.', 'admin_signup.html')

@app.route('/admin_login', methods=['GET','POST'])
def admin_login():
    if request.method=='POST':
        # Check if it's an API request (JSON) or form submission
        if request.is_json:
            # Handle JSON API request
            data = request.get_json()
            email = data.get('email', '').strip().lower()
            password = data.get('password', '')

            if not (email and password):
                return jsonify({'message': 'Email and password are required'}), 400

            db = get_db()
            c = db.cursor()
            c.execute('SELECT * FROM users WHERE email=? AND role=?', (email, 'admin'))
            row = c.fetchone()
            db.close()

            if row and check_password_hash(row['password'], password):
                return jsonify({
                    'message': 'Admin login successful',
                    'role': row['role'],
                    'name': row['name']
                }), 200
            else:
                return jsonify({'message': 'Invalid admin credentials'}), 401
        else:
            # Handle form submission
            email=request.form.get('email','').strip().lower()
            password=request.form.get('password','')
            db=get_db(); c=db.cursor()
            c.execute('SELECT * FROM users WHERE email=? AND role=?',(email,'admin'))
            row=c.fetchone()
            if row and check_password_hash(row['password'],password):
                create_session_for_user(row); flash('Admin login successful.','success'); return redirect(url_for('admin_dashboard'))
            flash('Invalid admin credentials.','error'); return redirect(url_for('admin_login'))

    return send_from_directory('.', 'admin_login.html')

# ---------------- Logout ----------------
@app.route('/logout')
def logout():
    session.clear(); flash('Logged out.','info'); return redirect(url_for('home'))

@app.route('/forgot_password', methods=['GET','POST'])
def forgot_password():
    if request.method=='POST':
        email = request.form.get('email','').strip().lower()
        if not email:
            flash('Email is required.', 'error')
            return render_template('forgot_password.html')
        # For demo purposes, just flash a message
        flash('If an account with that email exists, a password reset link has been sent (demo).', 'info')
        return render_template('forgot_password.html')
    return render_template('forgot_password.html')

# ---------------- User Dashboard ----------------
from flask import render_template, request

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    return render_template('user_dashboard.html')

@app.route('/send_money', methods=['GET', 'POST'])
def send_money():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        recipient_email = request.form.get('recipient_email', '').strip().lower()
        amount = request.form.get('amount', '').strip()

        if not recipient_email or not amount:
            flash('Recipient email and amount are required.', 'error')
            return redirect(url_for('send_money'))

        try:
            amount_value = float(amount)
            if amount_value <= 0:
                flash('Amount must be greater than zero.', 'error')
                return redirect(url_for('send_money'))
        except ValueError:
            flash('Invalid amount.', 'error')
            return redirect(url_for('send_money'))

        db = get_db()
        c = db.cursor()
        try:
            # Check if recipient exists
            c.execute('SELECT id FROM users WHERE email=?', (recipient_email,))
            recipient = c.fetchone()
            if not recipient:
                flash('Recipient not found.', 'error')
                return redirect(url_for('send_money'))

            # Insert transaction as a payment record for sender (simplified)
            c.execute('INSERT INTO payments (user_id, card_last4, amount, created_at) VALUES (?,?,?,?)',
                      (session['user_id'], None, amount_value, current_time_iso()))
            db.commit()
            flash(f'Sent ${amount_value:.2f} to {recipient_email}.', 'success')
        except sqlite3.Error as e:
            flash(f'Database error: {e}', 'error')
        finally:
            db.close()

        return redirect(url_for('send_money'))

    return render_template('send_money.html')

@app.route('/receive_money')
def receive_money():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    return render_template('receive_money.html')

@app.route('/transactions')
def transactions():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    db = get_db()
    c = db.cursor()
    c.execute('SELECT created_at, amount, card_last4 FROM payments WHERE user_id=? ORDER BY created_at DESC', (session['user_id'],))
    transactions = c.fetchall()
    db.close()

    return render_template('transactions.html', transactions=transactions)

@app.route('/user_settings', methods=['GET', 'POST'])
def user_settings():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        db = get_db()
        c = db.cursor()
        try:
            if password:
                hashed_password = generate_password_hash(password)
                c.execute('UPDATE users SET name=?, email=?, password=? WHERE id=?',
                          (name, email, hashed_password, session['user_id']))
            else:
                c.execute('UPDATE users SET name=?, email=? WHERE id=?',
                          (name, email, session['user_id']))
            db.commit()
            flash('Settings updated successfully.', 'success')
            # Update session info
            session['user_name'] = name
        except sqlite3.Error as e:
            flash(f'Database error: {e}', 'error')
        finally:
            db.close()
        return redirect(url_for('user_settings'))

    return render_template('user_settings.html')

@app.route('/bank_details', methods=['GET', 'POST'])
def bank_details():
    if 'user_id' not in session:
        flash('Please log in first.', 'error')
        return redirect(url_for('login'))

    if request.method == 'POST':
        bank_name = request.form.get('bank_name', '').strip()
        account_number = request.form.get('account_number', '').strip()
        ifsc_code = request.form.get('ifsc_code', '').strip()

        if not (bank_name and account_number and ifsc_code):
            flash('All fields are required.', 'error')
            return redirect(url_for('bank_details'))

        db = get_db()
        c = db.cursor()
        try:
            # Check if bank details already exist for the user
            c.execute('SELECT id FROM bank_details WHERE user_id=?', (session['user_id'],))
            existing = c.fetchone()
            if existing:
                # Update existing
                c.execute('UPDATE bank_details SET bank_name=?, account_number=?, ifsc_code=? WHERE id=?',
                          (bank_name, account_number, ifsc_code, existing['id']))
            else:
                # Insert new
                c.execute('INSERT INTO bank_details (user_id, bank_name, account_number, ifsc_code, created_at) VALUES (?,?,?,?,?)',
                          (session['user_id'], bank_name, account_number, ifsc_code, current_time_iso()))
            db.commit()
            flash('Bank details saved successfully.', 'success')
        except sqlite3.Error as e:
            flash(f'Database error: {e}', 'error')
        finally:
            db.close()
        return redirect(url_for('bank_details'))

    # GET request: fetch existing bank details
    db = get_db()
    c = db.cursor()
    c.execute('SELECT bank_name, account_number, ifsc_code FROM bank_details WHERE user_id=?', (session['user_id'],))
    bank_details_row = c.fetchone()
    db.close()

    bank_details_data = {}
    if bank_details_row:
        bank_details_data = {
            'bank_name': bank_details_row['bank_name'],
            'account_number': bank_details_row['account_number'],
            'ifsc_code': bank_details_row['ifsc_code']
        }

    return render_template('bank_details.html', bank_details=bank_details_data)

# ---------------- Admin Settings ----------------
@app.route('/admin_settings', methods=['GET', 'POST'])
def admin_settings():
    if 'role' not in session or session['role'] != 'admin':
        flash('Admin access required.', 'error')
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        db = get_db()
        c = db.cursor()
        try:
            if password:
                hashed_password = generate_password_hash(password)
                c.execute('UPDATE users SET name=?, email=?, password=? WHERE id=?',
                          (name, email, hashed_password, session['user_id']))
            else:
                c.execute('UPDATE users SET name=?, email=? WHERE id=?',
                          (name, email, session['user_id']))
            db.commit()
            flash('Settings updated successfully.', 'success')
            # Update session info
            session['user_name'] = name
        except sqlite3.Error as e:
            flash(f'Database error: {e}', 'error')
        finally:
            db.close()
        return redirect(url_for('admin_settings'))

    return render_template('admin_settings.html')

# Add card endpoint
@app.route('/add_card', methods=['POST'])
def add_card():
    if 'user_id' not in session:
        return jsonify({'message': 'Please log in first'}), 401

    card_number = request.form.get('card_number', '').strip()
    if not card_number or len(card_number) != 16 or not card_number.isdigit():
        flash('Please enter a valid 16-digit card number.', 'error')
        return redirect(url_for('dashboard'))

    masked, last4, brand = mask_card_number(card_number)

    db = get_db()
    c = db.cursor()
    try:
        c.execute('INSERT INTO cards (user_id, card_masked, last4, card_brand, created_at) VALUES (?,?,?,?,?)',
                  (session['user_id'], masked, last4, brand, current_time_iso()))
        db.commit()
        flash('Card added successfully.', 'success')
    except sqlite3.Error as e:
        flash(f'Database error: {e}', 'error')
    finally:
        db.close()

    return redirect(url_for('dashboard'))

# Make payment endpoint
@app.route('/make_payment', methods=['POST'])
def make_payment():
    if 'user_id' not in session:
        return jsonify({'message': 'Please log in first'}), 401

    card_id = request.form.get('card_id', '')
    amount = request.form.get('amount', '')

    if not card_id or not amount:
        flash('Card and amount are required.', 'error')
        return redirect(url_for('dashboard'))

    try:
        amount = float(amount)
        if amount <= 0:
            flash('Amount must be greater than 0.', 'error')
            return redirect(url_for('dashboard'))
    except ValueError:
        flash('Invalid amount.', 'error')
        return redirect(url_for('dashboard'))

    db = get_db()
    c = db.cursor()
    try:
        # Get card last4
        c.execute('SELECT last4 FROM cards WHERE id=? AND user_id=?', (card_id, session['user_id']))
        card = c.fetchone()

        if not card:
            flash('Card not found.', 'error')
            return redirect(url_for('dashboard'))

        # Insert payment
        c.execute('INSERT INTO payments (user_id, card_last4, amount, created_at) VALUES (?,?,?,?)',
                  (session['user_id'], card['last4'], amount, current_time_iso()))
        db.commit()
        flash(f'Payment of ${amount} processed successfully.', 'success')
    except sqlite3.Error as e:
        flash(f'Database error: {e}', 'error')
    finally:
        db.close()

    return redirect(url_for('dashboard'))

# ---------------- Admin Dashboard ----------------
from flask import render_template

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        flash('Admin access required.', 'error')
        return redirect(url_for('admin_login'))

    return render_template('admin_dashboard.html')

@app.route('/admin_transactions')
def admin_transactions():
    if 'role' not in session or session['role'] != 'admin':
        flash('Admin access required.', 'error')
        return redirect(url_for('admin_login'))

    return render_template('admin_transactions.html')

@app.route('/admin_users')
def admin_users():
    if 'role' not in session or session['role'] != 'admin':
        flash('Admin access required.', 'error')
        return redirect(url_for('admin_login'))

    return render_template('admin_users.html')

# ---------------- API Endpoints ----------------

# Get all users (Admin only)
@app.route('/api/users', methods=['GET'])
@admin_required
def get_users():
    db = get_db()
    c = db.cursor()
    c.execute('SELECT id, name, email, role FROM users ORDER BY id')
    users = [dict(row) for row in c.fetchall()]
    db.close()
    return jsonify(users), 200

# Get user by ID (Admin only)
@app.route('/api/users/<int:user_id>', methods=['GET'])
@admin_required
def get_user(user_id):
    db = get_db()
    c = db.cursor()
    c.execute('SELECT id, name, email, role FROM users WHERE id=?', (user_id,))
    user = c.fetchone()
    db.close()

    if user:
        return jsonify(dict(user)), 200
    else:
        return jsonify({'message': 'User not found'}), 404

# Delete user (Admin only)
@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    db = get_db()
    c = db.cursor()
    try:
        c.execute('DELETE FROM users WHERE id=?', (user_id,))
        db.commit()
        if c.rowcount > 0:
            return jsonify({'message': 'User deleted successfully'}), 200
        else:
            return jsonify({'message': 'User not found'}), 404
    except sqlite3.Error as e:
        return jsonify({'message': f'Database error: {e}'}), 500
    finally:
        db.close()

# Get all cards (Admin only)
@app.route('/api/cards', methods=['GET'])
@admin_required
def get_cards():
    db = get_db()
    c = db.cursor()
    c.execute('''
        SELECT c.id, c.user_id, c.card_masked, c.last4, c.card_brand, c.created_at,
               u.name as user_name, u.email as user_email
        FROM cards c
        JOIN users u ON c.user_id = u.id
        ORDER BY c.created_at DESC
    ''')
    cards = [dict(row) for row in c.fetchall()]
    db.close()
    return jsonify(cards), 200

# Get cards for specific user (Admin only)
@app.route('/api/users/<int:user_id>/cards', methods=['GET'])
@admin_required
def get_user_cards(user_id):
    db = get_db()
    c = db.cursor()
    c.execute('''
        SELECT c.id, c.card_masked, c.last4, c.card_brand, c.created_at
        FROM cards c
        WHERE c.user_id = ?
        ORDER BY c.created_at DESC
    ''', (user_id,))
    cards = [dict(row) for row in c.fetchall()]
    db.close()
    return jsonify(cards), 200

# Get all payments (Admin only)
@app.route('/api/payments', methods=['GET'])
@admin_required
def get_payments():
    db = get_db()
    c = db.cursor()
    c.execute('''
        SELECT p.id, p.user_id, p.card_last4, p.amount, p.created_at,
               u.name as user_name, u.email as user_email
        FROM payments p
        JOIN users u ON p.user_id = u.id
        ORDER BY p.created_at DESC
    ''')
    payments = [dict(row) for row in c.fetchall()]
    db.close()
    return jsonify(payments), 200

# Get payments for specific user (Admin only)
@app.route('/api/users/<int:user_id>/payments', methods=['GET'])
@admin_required
def get_user_payments(user_id):
    db = get_db()
    c = db.cursor()
    c.execute('''
        SELECT p.id, p.card_last4, p.amount, p.created_at
        FROM payments p
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC
    ''', (user_id,))
    payments = [dict(row) for row in c.fetchall()]
    db.close()
    return jsonify(payments), 200

# Get payment statistics (Admin only)
@app.route('/api/stats', methods=['GET'])
@admin_required
def get_stats():
    db = get_db()
    c = db.cursor()

    # Get user counts
    c.execute("SELECT COUNT(*) as total_users FROM users WHERE role='user'")
    total_users = c.fetchone()['total_users']

    c.execute("SELECT COUNT(*) as total_admins FROM users WHERE role='admin'")
    total_admins = c.fetchone()['total_admins']

    # Get card counts
    c.execute("SELECT COUNT(*) as total_cards FROM cards")
    total_cards = c.fetchone()['total_cards']

    # Get payment statistics
    c.execute("SELECT COUNT(*) as total_payments, SUM(amount) as total_amount FROM payments")
    payment_stats = c.fetchone()

    db.close()

    return jsonify({
        'total_users': total_users,
        'total_admins': total_admins,
        'total_cards': total_cards,
        'total_payments': payment_stats['total_payments'] or 0,
        'total_amount': payment_stats['total_amount'] or 0
    }), 200

# ---------------- Initialize DB and default admin ----------------
if __name__=="__main__":
    init_db()
    db=get_db(); c=db.cursor()
    c.execute("SELECT COUNT(*) as c FROM users WHERE role='admin'")
    row=c.fetchone()
    if row and row['c']==0:
        c.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
                  ('Admin','admin@example.com',generate_password_hash('admin123'),'admin'))
        db.commit()
        print('Created default admin: admin@example.com / admin123')
    app.run(host='0.0.0.0', debug=True, port=5502)
