import unittest
from app import app, init_db, get_db
from werkzeug.security import generate_password_hash

class AuthTestCase(unittest.TestCase):
    def setUp(self):
        # Set up test client and initialize DB
        self.app = app.test_client()
        app.config['TESTING'] = True
        init_db()
        # Clear users table and add a test user
        db = get_db()
        c = db.cursor()
        c.execute('DELETE FROM users')
        c.execute('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)',
                  ('Test User', 'testuser@example.com', generate_password_hash('testpass'), 'user'))
        db.commit()
        db.close()

    def test_login_page_served(self):
        response = self.app.get('/login')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<form', response.data)
        self.assertIn(b'Login', response.data)

    def test_signup_page_served(self):
        response = self.app.get('/signup')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<form', response.data)
        self.assertIn(b'Sign Up', response.data)

    def test_forgot_password_page_served(self):
        response = self.app.get('/forgot_password')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Enter your email', response.data)

    def test_successful_login(self):
        response = self.app.post('/login', json={
            'email': 'testuser@example.com',
            'password': 'testpass'
        })
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Login successful', response.data)

    def test_failed_login_wrong_password(self):
        response = self.app.post('/login', json={
            'email': 'testuser@example.com',
            'password': 'wrongpass'
        })
        self.assertEqual(response.status_code, 401)
        self.assertIn(b'Invalid credentials', response.data)

    def test_failed_login_nonexistent_user(self):
        response = self.app.post('/login', json={
            'email': 'nonexistent@example.com',
            'password': 'testpass'
        })
        self.assertEqual(response.status_code, 401)
        self.assertIn(b'Invalid credentials', response.data)

    def test_successful_signup(self):
        response = self.app.post('/signup', json={
            'name': 'New User',
            'email': 'newuser@example.com',
            'password': 'newpass'
        })
        self.assertEqual(response.status_code, 201)
        self.assertIn(b'User created successfully', response.data)

    def test_failed_signup_duplicate_email(self):
        response = self.app.post('/signup', json={
            'name': 'Test User',
            'email': 'testuser@example.com',
            'password': 'testpass'
        })
        self.assertEqual(response.status_code, 409)
        self.assertIn(b'Email already exists', response.data)

    def test_failed_signup_missing_fields(self):
        response = self.app.post('/signup', json={
            'name': 'New User',
            'email': '',
            'password': 'newpass'
        })
        self.assertEqual(response.status_code, 400)
        self.assertIn(b'Name, email, and password are required', response.data)

    def test_forgot_password_success(self):
        response = self.app.post('/forgot_password', data={
            'email': 'testuser@example.com'
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'password reset link has been sent', response.data)

    def test_forgot_password_missing_email(self):
        response = self.app.post('/forgot_password', data={
            'email': ''
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Email is required', response.data)

if __name__ == '__main__':
    unittest.main()
